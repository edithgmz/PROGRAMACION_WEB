<?php

/*
 * Instituto Tecnológico de Chihuahua II
 * Carrera: Ingeniería en Sistemas Computacionales
 * Materia: Programación Web
 * 
 * Aluma: Priscila Edith Gómez Rascón
 * Número de Control: 15551384
 */

echo "Copyright &copy; " . date("Y") . " Priscila Gómez";
