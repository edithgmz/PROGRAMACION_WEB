<!DOCTYPE html>
<!--
Instituto Tecnológico de Chihuahua II
Carrera: Ingeniería en Sistemas Computacionales
Materia: Programación Web

Aluma: Priscila Edith Gómez Rascón
Número de Control: 15551384
-->
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
        <link rel="stylesheet" href="estilo.css">
    </head>
    <body>
        <ol>
            <li>
                <a href="phparreglomulti.php" target="frame">
                    Arreglos Multidimensionales PHP
                </a>
            </li>
            
            <li>
                <a href="phpfechahora.php" target="frame">
                    Fecha y Hora PHP
                </a>
            </li>
            
            <li>
                <a href="phparchivos.php" target="frame">
                    Archivos PHP
                </a>
            </li>
            
            <li>
                <a href="phpcookies.php" target="frame">
                    Cookies PHP
                </a>
            </li>
            
            <li>
                <a href="phpsesiones.php" target="frame">
                    Sesiones PHP
                </a>
            </li>
            
            <li>
                <a href="phpfiltros.php" target="frame">
                    Filtros PHP
                </a>
            </li>
            
            <li>
                <a href="phpmanejoerror.php" target="frame">
                    Manejo de Errores PHP
                </a>
            </li>
            
            <li>
                <a href="phpexcepciones.php" target="frame">
                    Excepciones PHP
                </a>
            </li>
            
        </ol>
    </body>
</html>
